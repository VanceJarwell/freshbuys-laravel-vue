import Vue from 'vue';
import VueRouter from 'vue-router';

Vue.use(VueRouter)
//TEMPLATES
import App from './../views/ordering/App'
import NotFound from './../views/ordering/errors/404'

//BACKEND
import Dashboard from './../views/ordering/dashboard/Index'
import Login from '../views/ordering/auth/Login'
import Logout from '../views/ordering/auth/Logout'

export const router = new VueRouter({
    mode: 'history',
    routes: [
        //BACKEND
        {
            path: '/',
            name: 'home',
            component: Dashboard,
            meta: {
                title: 'Dashboard',
            }
        },
        {
            path: '/login',
            name: 'login',
            component: Login,
            meta: {
                title: 'Login',
            }
        },
        {
            path: '/logout',
            name: 'logout',
            component: Logout,
            meta: {
                title: 'Login',
            }
        },
        {
            path: '/*',
            name: '404',
            component: NotFound,
            meta: {
                title: '404 Page Not Found',
            }
        },
    ],
});


export default router;