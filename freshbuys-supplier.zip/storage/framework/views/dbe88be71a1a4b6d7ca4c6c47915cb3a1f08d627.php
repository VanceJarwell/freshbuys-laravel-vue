<script src="/js/jquery.min.js"></script>
<script src="/js/popper.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/script.js"></script><?php /**PATH /home/jrdatolfreshbuys/freshbuys_warehouse/resources/views/ordering/layout/scripts.blade.php ENDPATH**/ ?>