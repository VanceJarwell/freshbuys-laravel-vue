<html>
<head>
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <style>
        @import  url(https://fonts.googleapis.com/css?family=Raleway:400,300);
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('build/css/main-style.css')); ?>">

</head>
<body>
<div id="app">
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?> hihi
    </form>
    <router-view></router-view>
</div>
</body>
<script>
    window.loggedUser = <?php echo auth()->user()  ? auth()->user() : ''; ?>

</script>
<?php echo $__env->yieldContent('script'); ?>
</html><?php /**PATH D:\xampp\htdocs\freshbuys\resources\views/layouts/app.blade.php ENDPATH**/ ?>